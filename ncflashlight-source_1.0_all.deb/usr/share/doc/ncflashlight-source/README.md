# NCFlashlight 1.0 — Theos starter project

Target: jailbroken iPhone 4S, iOS 6.1.3 (ARMv7).

**This is source, not an installable `.deb`.** A working iOS 5/6 Notification Center
"WeeApp" needs to be compiled against a compatible iOS SDK and Theos legacy
Notification Center widget template. This archive intentionally does not pretend
to be a finished binary package.

## Build environment on your Mac

1. Install a Theos toolchain that still supports the iOS 6 / ARMv7 target and an
   iOS 6.1 SDK. Current Xcode alone may not include that SDK.
2. Install Theos' legacy templates:
   ```sh
   git clone https://github.com/theos/templates-legacy.git "$THEOS/mod/templates-legacy"
   ```
3. Generate the actual iOS 5–6 Notification Center widget skeleton:
   ```sh
   "$THEOS/bin/nic.pl"
   ```
   Select `iphone/notification_center_widget`, then use:
   - Project name: `NCFlashlight`
   - Package: `com.retrolabs.ncflashlight`
   - Author: your name
4. Copy `TorchController.m` from this archive into the generated widget project,
   then integrate its `NCFlashlightSetTorch` helper into the generated controller's
   button action. Keep the controller/protocol files from the Theos template:
   their exact method signatures are part of the legacy widget ABI.
5. Set the package control fields to the values in `control.example`, build with
   `make package`, and inspect the resulting `.deb` before installing.

## Device safety

- Test with a backup and a way to remove the package (SSH/iFile/Cydia).
- Do not run `make install` on your daily-driver phone until the package has been
  tested and its install paths inspected.
- The helper checks camera/torch availability and reports failure rather than
  changing system-wide settings.
- The LED can get hot; turn it off when not needed.

## Why no `.deb` is included

A real Notification Center widget is a compiled ARMv7 bundle loaded by SpringBoard.
This environment does not have your Mac's Theos toolchain or the iOS 6 SDK, so
producing a purported installable `.deb` here would be misleading.
